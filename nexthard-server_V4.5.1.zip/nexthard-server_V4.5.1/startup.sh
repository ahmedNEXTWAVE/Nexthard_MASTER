sudo node nexthard-server.js



